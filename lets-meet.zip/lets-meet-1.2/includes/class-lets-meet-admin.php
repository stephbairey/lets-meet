<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Admin pages, menu registration, and form handlers.
 */
class Lets_Meet_Admin {

	/** @var Lets_Meet_Services */
	private $services;

	/** @var Lets_Meet_Gcal */
	private $gcal;

	/** @var Lets_Meet_Bookings */
	private $bookings;

	/** @var Lets_Meet_Zoom */
	private $zoom;

	public function __construct( Lets_Meet_Services $services, Lets_Meet_Gcal $gcal, Lets_Meet_Bookings $bookings, Lets_Meet_Zoom $zoom = null ) {
		$this->services = $services;
		$this->gcal     = $gcal;
		$this->bookings = $bookings;
		$this->zoom     = $zoom;
	}

	/**
	 * Register the admin menu.
	 */
	public function register_menu() {
		add_menu_page(
			__( 'Let\'s Meet', 'lets-meet' ),
			__( 'Let\'s Meet', 'lets-meet' ),
			'manage_options',
			'lets-meet',
			[ $this, 'render_bookings_page' ],
			'dashicons-calendar-alt',
			30
		);

		add_submenu_page(
			'lets-meet',
			__( 'Bookings', 'lets-meet' ),
			__( 'Bookings', 'lets-meet' ),
			'manage_options',
			'lets-meet',
			[ $this, 'render_bookings_page' ]
		);

		add_submenu_page(
			'lets-meet',
			__( 'Services', 'lets-meet' ),
			__( 'Services', 'lets-meet' ),
			'manage_options',
			'lets-meet-services',
			[ $this, 'render_services_page' ]
		);

		add_submenu_page(
			'lets-meet',
			__( 'Settings', 'lets-meet' ),
			__( 'Settings', 'lets-meet' ),
			'manage_options',
			'lets-meet-settings',
			[ $this, 'render_settings_page' ]
		);
	}

	/**
	 * Enqueue admin assets only on Let's Meet pages.
	 */
	public function enqueue_admin_assets( $hook ) {
		if ( strpos( $hook, 'lets-meet' ) === false ) {
			return;
		}

		wp_enqueue_style(
			'lm-admin',
			LM_URL . 'assets/css/admin.css',
			[],
			LM_VERSION
		);

		wp_enqueue_script(
			'lm-admin',
			LM_URL . 'assets/js/admin.js',
			[],
			LM_VERSION,
			true
		);

		// Localize data for admin reschedule page.
		$page   = sanitize_text_field( $_GET['page'] ?? '' );
		$action = sanitize_text_field( $_GET['action'] ?? '' );
		if ( 'lets-meet' === $page && 'reschedule' === $action && ! empty( $_GET['booking_id'] ) ) {
			$booking = $this->bookings->get( absint( $_GET['booking_id'] ) );
			if ( $booking ) {
				wp_localize_script( 'lm-admin', 'lmAdminData', [
					'ajaxUrl'   => admin_url( 'admin-ajax.php' ),
					'nonce'     => wp_create_nonce( 'lm_frontend_nonce' ),
					'serviceId' => absint( $booking->service_id ),
				] );
			}
		}
	}

	/**
	 * Handle admin actions that require a redirect before headers are sent.
	 *
	 * Hooked to admin_init so wp_safe_redirect() works properly.
	 */
	public function handle_early_actions() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		$page   = sanitize_text_field( $_GET['page'] ?? '' );
		$action = sanitize_text_field( $_GET['action'] ?? '' );

		// Service toggle.
		if ( 'lets-meet-services' === $page && 'toggle' === $action ) {
			$this->handle_toggle_service();
			return;
		}

		// Single booking cancel.
		if ( 'lets-meet' === $page && 'cancel' === $action ) {
			$this->handle_cancel_booking();
			return;
		}

		// Bulk cancel (POST from list table).
		if ( 'lets-meet' === $page && isset( $_POST['action'] ) ) {
			$post_action  = sanitize_text_field( $_POST['action'] );
			$post_action2 = sanitize_text_field( $_POST['action2'] ?? '' );
			if ( 'bulk_cancel' === $post_action || 'bulk_cancel' === $post_action2 ) {
				$this->handle_bulk_cancel();
			}
		}
	}

	/* ── Bookings page ────────────────────────────────────────────── */

	/**
	 * Render the bookings page — list or detail view.
	 */
	public function render_bookings_page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		$action = sanitize_text_field( $_GET['action'] ?? '' );

		if ( 'view' === $action && ! empty( $_GET['booking_id'] ) ) {
			$this->render_booking_detail( absint( $_GET['booking_id'] ) );
			return;
		}

		if ( 'reschedule' === $action && ! empty( $_GET['booking_id'] ) ) {
			$this->render_admin_reschedule( absint( $_GET['booking_id'] ) );
			return;
		}

		$this->render_bookings_list();
	}

	/**
	 * Render the bookings list table.
	 */
	private function render_bookings_list() {
		$table = new Lets_Meet_Bookings_Table();
		$table->prepare_items();

		echo '<div class="wrap">';
		echo '<h1 class="wp-heading-inline">' . esc_html__( 'Bookings', 'lets-meet' ) . '</h1>';

		// Admin notices for cancel actions.
		if ( isset( $_GET['cancelled'] ) ) {
			$count = absint( $_GET['cancelled'] );
			echo '<div class="notice notice-success is-dismissible"><p>';
			printf(
				/* translators: %d: number of bookings cancelled */
				esc_html( _n( '%d booking cancelled.', '%d bookings cancelled.', $count, 'lets-meet' ) ),
				$count
			);
			echo '</p></div>';
		}

		echo '<form method="post">';
		$table->views();
		$table->display();
		echo '</form>';
		echo '</div>';
	}

	/**
	 * Render the single booking detail view.
	 *
	 * @param int $booking_id Booking ID.
	 */
	private function render_booking_detail( $booking_id ) {
		$booking = $this->bookings->get( $booking_id );

		if ( ! $booking ) {
			echo '<div class="wrap">';
			echo '<h1>' . esc_html__( 'Booking Not Found', 'lets-meet' ) . '</h1>';
			echo '<p>' . esc_html__( 'The requested booking does not exist.', 'lets-meet' ) . '</p>';
			echo '<a href="' . esc_url( admin_url( 'admin.php?page=lets-meet' ) ) . '">&larr; '
				. esc_html__( 'Back to Bookings', 'lets-meet' ) . '</a>';
			echo '</div>';
			return;
		}

		// Convert start_utc to site timezone for display.
		try {
			$tz = new DateTimeZone( $booking->site_timezone ?: wp_timezone_string() );
		} catch ( Exception $e ) {
			$tz = wp_timezone();
		}
		$start = new DateTimeImmutable( $booking->start_utc, new DateTimeZone( 'UTC' ) );
		$local = $start->setTimezone( $tz );

		// Get service name.
		$service = $this->services->get( $booking->service_id );
		$service_name = $service ? $service->name : __( '(deleted)', 'lets-meet' );

		echo '<div class="wrap">';
		echo '<h1>' . esc_html__( 'Booking Details', 'lets-meet' ) . '</h1>';

		// Reschedule success notice.
		if ( ! empty( $_GET['rescheduled'] ) ) {
			echo '<div class="notice notice-success is-dismissible"><p>'
				. esc_html__( 'Booking rescheduled successfully.', 'lets-meet' ) . '</p></div>';
		}

		// Error notice.
		if ( ! empty( $_GET['lm_error'] ) ) {
			$error_msg = get_transient( 'lm_admin_error_' . get_current_user_id() );
			if ( $error_msg ) {
				delete_transient( 'lm_admin_error_' . get_current_user_id() );
				echo '<div class="notice notice-error is-dismissible"><p>' . esc_html( $error_msg ) . '</p></div>';
			}
		}

		echo '<a href="' . esc_url( admin_url( 'admin.php?page=lets-meet' ) ) . '">&larr; '
			. esc_html__( 'Back to Bookings', 'lets-meet' ) . '</a>';

		echo '<table class="form-table lm-booking-detail" role="presentation">';

		// Payment override notices.
		if ( ! empty( $_GET['payment_updated'] ) ) {
			echo '<div class="notice notice-success is-dismissible"><p>'
				. esc_html__( 'Payment status updated.', 'lets-meet' ) . '</p></div>';
		}

		// Status.
		$status_labels = [
			'confirmed'       => __( 'Confirmed', 'lets-meet' ),
			'cancelled'       => __( 'Cancelled', 'lets-meet' ),
			'pending_payment' => __( 'Pending Payment', 'lets-meet' ),
		];
		$status_label = $status_labels[ $booking->status ] ?? $booking->status;
		$status_classes = [
			'confirmed'       => 'lm-status-confirmed',
			'cancelled'       => 'lm-status-cancelled',
			'pending_payment' => 'lm-status-pending-payment',
		];
		$status_class = $status_classes[ $booking->status ] ?? '';

		echo '<tr><th>' . esc_html__( 'Status', 'lets-meet' ) . '</th><td>'
			. '<span class="lm-status ' . esc_attr( $status_class ) . '">' . esc_html( $status_label ) . '</span>'
			. '</td></tr>';

		// Service.
		echo '<tr><th>' . esc_html__( 'Service', 'lets-meet' ) . '</th><td>'
			. esc_html( $service_name ) . '</td></tr>';

		// Date.
		echo '<tr><th>' . esc_html__( 'Date', 'lets-meet' ) . '</th><td>'
			. esc_html( wp_date( 'l, F j, Y', $local->getTimestamp() ) ) . '</td></tr>';

		// Time.
		echo '<tr><th>' . esc_html__( 'Time', 'lets-meet' ) . '</th><td>'
			. esc_html( wp_date( 'g:i A', $local->getTimestamp() ) ) . '</td></tr>';

		// Duration.
		echo '<tr><th>' . esc_html__( 'Duration', 'lets-meet' ) . '</th><td>'
			. sprintf(
				/* translators: %d: number of minutes */
				esc_html__( '%d minutes', 'lets-meet' ),
				absint( $booking->duration )
			)
			. '</td></tr>';

		// Client name.
		echo '<tr><th>' . esc_html__( 'Client Name', 'lets-meet' ) . '</th><td>'
			. esc_html( $booking->client_name ) . '</td></tr>';

		// Client email.
		echo '<tr><th>' . esc_html__( 'Client Email', 'lets-meet' ) . '</th><td>'
			. '<a href="mailto:' . esc_attr( $booking->client_email ) . '">'
			. esc_html( $booking->client_email ) . '</a></td></tr>';

		// Client phone.
		if ( ! empty( $booking->client_phone ) ) {
			echo '<tr><th>' . esc_html__( 'Client Phone', 'lets-meet' ) . '</th><td>'
				. esc_html( $booking->client_phone ) . '</td></tr>';
		}

		// Client notes.
		if ( ! empty( $booking->client_notes ) ) {
			echo '<tr><th>' . esc_html__( 'Notes', 'lets-meet' ) . '</th><td>'
				. esc_html( $booking->client_notes ) . '</td></tr>';
		}

		// GCal event.
		if ( ! empty( $booking->gcal_event_id ) ) {
			$gcal_label = 'cancelled' === $booking->status
				? __( 'Event deleted', 'lets-meet' )
				: __( 'Synced', 'lets-meet' );
			echo '<tr><th>' . esc_html__( 'Google Calendar', 'lets-meet' ) . '</th><td>'
				. esc_html( $gcal_label ) . '</td></tr>';
		}

		// Zoom meeting.
		if ( ! empty( $booking->zoom_join_url ) ) {
			if ( 'cancelled' === $booking->status ) {
				echo '<tr><th>' . esc_html__( 'Zoom', 'lets-meet' ) . '</th><td>'
					. esc_html__( 'Meeting deleted', 'lets-meet' ) . '</td></tr>';
			} else {
				echo '<tr><th>' . esc_html__( 'Zoom', 'lets-meet' ) . '</th><td>'
					. '<a href="' . esc_url( $booking->zoom_join_url ) . '" target="_blank">'
					. esc_html( $booking->zoom_join_url ) . '</a></td></tr>';
			}
		}

		// Booked at.
		echo '<tr><th>' . esc_html__( 'Booked At', 'lets-meet' ) . '</th><td>'
			. esc_html( wp_date( 'M j, Y — g:i A', strtotime( $booking->created_at ) ) )
			. '</td></tr>';

		// Payment section.
		$ps = $booking->payment_status ?? 'none';
		if ( 'none' !== $ps ) {
			$payment_labels = [
				'pending' => __( 'Pending', 'lets-meet' ),
				'paid'    => __( 'Paid', 'lets-meet' ),
				'waived'  => __( 'Waived', 'lets-meet' ),
			];
			$payment_classes = [
				'pending' => 'lm-payment-pending',
				'paid'    => 'lm-payment-paid',
				'waived'  => 'lm-payment-waived',
			];

			echo '<tr><th>' . esc_html__( 'Payment Status', 'lets-meet' ) . '</th><td>'
				. '<span class="lm-status ' . esc_attr( $payment_classes[ $ps ] ?? '' ) . '">'
				. esc_html( $payment_labels[ $ps ] ?? $ps ) . '</span>'
				. '</td></tr>';

			if ( 'paid' === $ps ) {
				if ( ! empty( $booking->payment_amount ) ) {
					echo '<tr><th>' . esc_html__( 'Amount Paid', 'lets-meet' ) . '</th><td>$'
						. esc_html( number_format( (float) $booking->payment_amount, 2 ) ) . '</td></tr>';
				}
				if ( ! empty( $booking->payment_txn_id ) ) {
					echo '<tr><th>' . esc_html__( 'Transaction ID', 'lets-meet' ) . '</th><td>'
						. esc_html( $booking->payment_txn_id ) . '</td></tr>';
				}
				if ( ! empty( $booking->payment_date ) ) {
					echo '<tr><th>' . esc_html__( 'Payment Date', 'lets-meet' ) . '</th><td>'
						. esc_html( wp_date( 'M j, Y — g:i A', strtotime( $booking->payment_date ) ) )
						. '</td></tr>';
				}
			}
		}

		echo '</table>';

		// Manual payment override for pending bookings.
		if ( 'pending' === $ps ) {
			echo '<h3>' . esc_html__( 'Payment Actions', 'lets-meet' ) . '</h3>';

			// Mark as Paid form.
			echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" style="display:inline-block; margin-right: 12px;">';
			echo '<input type="hidden" name="action" value="lm_mark_paid">';
			echo '<input type="hidden" name="booking_id" value="' . absint( $booking->id ) . '">';
			wp_nonce_field( 'lm_mark_paid_' . $booking->id, 'lm_nonce' );
			echo '<label>' . esc_html__( 'Amount:', 'lets-meet' ) . ' <input type="number" name="amount" step="0.01" min="0" value="'
				. esc_attr( $service ? number_format( (float) $service->price, 2, '.', '' ) : '0.00' )
				. '" style="width:80px;"></label> ';
			echo '<label>' . esc_html__( 'Txn ID:', 'lets-meet' ) . ' <input type="text" name="txn_id" value="" placeholder="' . esc_attr__( 'optional', 'lets-meet' ) . '" style="width:140px;"></label> ';
			echo '<button type="submit" class="button button-primary">' . esc_html__( 'Mark as Paid', 'lets-meet' ) . '</button>';
			echo '</form>';

			// Mark as Waived form.
			$waive_url = wp_nonce_url(
				add_query_arg( [
					'page'       => 'lets-meet',
					'action'     => 'view',
					'booking_id' => absint( $booking->id ),
				], admin_url( 'admin.php' ) ),
				'lm_mark_waived_' . $booking->id
			);
			echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" style="display:inline-block;">';
			echo '<input type="hidden" name="action" value="lm_mark_waived">';
			echo '<input type="hidden" name="booking_id" value="' . absint( $booking->id ) . '">';
			wp_nonce_field( 'lm_mark_waived_' . $booking->id, 'lm_nonce' );
			echo '<button type="submit" class="button">' . esc_html__( 'Mark as Waived', 'lets-meet' ) . '</button>';
			echo '</form>';
		}

		// Action buttons.
		if ( 'cancelled' !== $booking->status ) {
			$reschedule_url = add_query_arg( [
				'page'       => 'lets-meet',
				'action'     => 'reschedule',
				'booking_id' => absint( $booking->id ),
			], admin_url( 'admin.php' ) );

			$cancel_url = wp_nonce_url(
				add_query_arg( [
					'page'       => 'lets-meet',
					'action'     => 'cancel',
					'booking_id' => absint( $booking->id ),
				], admin_url( 'admin.php' ) ),
				'lm_cancel_booking_' . $booking->id
			);

			echo '<p class="submit">';
			echo '<a href="' . esc_url( $reschedule_url ) . '" class="button button-primary">'
				. esc_html__( 'Reschedule', 'lets-meet' ) . '</a> ';
			echo '<a href="' . esc_url( $cancel_url ) . '" class="button button-secondary lm-cancel-link" style="color: #b32d2e;">'
				. esc_html__( 'Cancel Booking', 'lets-meet' ) . '</a>';
			echo '</p>';
		}

		echo '</div>';
	}

	/* ── Booking action handlers ─────────────────────────────────── */

	/**
	 * Handle single booking cancellation.
	 */
	private function handle_cancel_booking() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Unauthorized.', 'lets-meet' ) );
		}

		$booking_id = absint( $_GET['booking_id'] ?? 0 );

		if ( ! wp_verify_nonce( $_GET['_wpnonce'] ?? '', 'lm_cancel_booking_' . $booking_id ) ) {
			wp_die( esc_html__( 'Invalid nonce. Please try again.', 'lets-meet' ) );
		}

		$cancelled = 0;
		if ( $this->bookings->cancel( $booking_id ) ) {
			$cancelled = 1;
		}

		wp_safe_redirect( add_query_arg( [
			'page'      => 'lets-meet',
			'cancelled' => $cancelled,
		], admin_url( 'admin.php' ) ) );
		exit;
	}

	/* ── Admin reschedule ─────────────────────────────────────────── */

	/**
	 * Render the admin reschedule page.
	 *
	 * @param int $booking_id Booking ID.
	 */
	private function render_admin_reschedule( $booking_id ) {
		$booking = $this->bookings->get( $booking_id );

		if ( ! $booking || 'cancelled' === $booking->status ) {
			echo '<div class="wrap">';
			echo '<h1>' . esc_html__( 'Cannot Reschedule', 'lets-meet' ) . '</h1>';
			echo '<p>' . esc_html__( 'This booking does not exist or has been cancelled.', 'lets-meet' ) . '</p>';
			echo '<a href="' . esc_url( admin_url( 'admin.php?page=lets-meet' ) ) . '">&larr; '
				. esc_html__( 'Back to Bookings', 'lets-meet' ) . '</a>';
			echo '</div>';
			return;
		}

		// Convert for display.
		try {
			$tz = new \DateTimeZone( $booking->site_timezone ?: wp_timezone_string() );
		} catch ( \Exception $e ) {
			$tz = wp_timezone();
		}
		$start        = new \DateTimeImmutable( $booking->start_utc, new \DateTimeZone( 'UTC' ) );
		$local        = $start->setTimezone( $tz );
		$service      = $this->services->get( $booking->service_id );
		$service_name = $service ? $service->name : __( '(deleted)', 'lets-meet' );

		echo '<div class="wrap">';
		echo '<h1>' . esc_html__( 'Reschedule Booking', 'lets-meet' ) . '</h1>';
		echo '<a href="' . esc_url( admin_url( 'admin.php?page=lets-meet&action=view&booking_id=' . absint( $booking->id ) ) ) . '">&larr; '
			. esc_html__( 'Back to Booking', 'lets-meet' ) . '</a>';

		// Current booking summary.
		echo '<div style="background: #f0f6fc; border-radius: 6px; padding: 16px 20px; margin: 16px 0 24px; max-width: 500px;">';
		echo '<p style="margin: 0 0 4px; font-size: 13px; color: #646970; text-transform: uppercase;">' . esc_html__( 'Current Booking', 'lets-meet' ) . '</p>';
		echo '<p style="margin: 0; font-weight: 600;">' . esc_html( $service_name ) . '</p>';
		echo '<p style="margin: 4px 0 0;">' . esc_html( wp_date( 'l, F j, Y', $local->getTimestamp() ) ) . ' &mdash; ' . esc_html( wp_date( 'g:i A', $local->getTimestamp() ) ) . '</p>';
		echo '</div>';

		// Date picker form.
		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" id="lm-admin-reschedule-form">';
		echo '<input type="hidden" name="action" value="lm_admin_reschedule">';
		echo '<input type="hidden" name="booking_id" value="' . absint( $booking->id ) . '">';
		wp_nonce_field( 'lm_admin_reschedule_' . $booking->id, '_wpnonce' );

		echo '<table class="form-table"><tbody>';

		// Date input.
		echo '<tr><th scope="row"><label for="lm-new-date">' . esc_html__( 'New Date', 'lets-meet' ) . '</label></th>';
		$settings = get_option( 'lm_settings', [] );
		$min_date = current_datetime()->format( 'Y-m-d' );
		$max_date = current_datetime()->modify( '+' . absint( $settings['horizon'] ?? 60 ) . ' days' )->format( 'Y-m-d' );
		echo '<td><input type="date" id="lm-new-date" name="new_date" min="' . esc_attr( $min_date ) . '" max="' . esc_attr( $max_date ) . '" required></td></tr>';

		// Time slot select (populated via JS after date change).
		echo '<tr><th scope="row"><label for="lm-new-time">' . esc_html__( 'New Time', 'lets-meet' ) . '</label></th>';
		echo '<td><select id="lm-new-time" name="new_time" required disabled>';
		echo '<option value="">' . esc_html__( 'Select a date first', 'lets-meet' ) . '</option>';
		echo '</select><span id="lm-slots-spinner" style="display:none; margin-left: 8px;">' . esc_html__( 'Loading...', 'lets-meet' ) . '</span></td></tr>';

		echo '</tbody></table>';

		echo '<p class="submit"><button type="submit" class="button button-primary" id="lm-reschedule-submit" disabled>'
			. esc_html__( 'Confirm Reschedule', 'lets-meet' ) . '</button></p>';
		echo '</form>';
		echo '</div>';
	}

	/**
	 * Handle admin reschedule form POST.
	 *
	 * Hooked to admin_post_lm_admin_reschedule.
	 */
	public function handle_admin_reschedule() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Unauthorized.', 'lets-meet' ) );
		}

		$booking_id = absint( $_POST['booking_id'] ?? 0 );

		if ( ! wp_verify_nonce( $_POST['_wpnonce'] ?? '', 'lm_admin_reschedule_' . $booking_id ) ) {
			wp_die( esc_html__( 'Invalid nonce. Please try again.', 'lets-meet' ) );
		}

		$new_date = sanitize_text_field( $_POST['new_date'] ?? '' );
		$new_time = sanitize_text_field( $_POST['new_time'] ?? '' );

		$result = $this->bookings->reschedule( $booking_id, $new_date, $new_time );

		if ( is_wp_error( $result ) ) {
			// Store error and redirect back.
			set_transient( 'lm_admin_error_' . get_current_user_id(), $result->get_error_message(), 30 );
			wp_safe_redirect( add_query_arg( [
				'page'       => 'lets-meet',
				'action'     => 'reschedule',
				'booking_id' => $booking_id,
				'lm_error'   => '1',
			], admin_url( 'admin.php' ) ) );
			exit;
		}

		wp_safe_redirect( add_query_arg( [
			'page'          => 'lets-meet',
			'action'        => 'view',
			'booking_id'    => $booking_id,
			'rescheduled'   => '1',
		], admin_url( 'admin.php' ) ) );
		exit;
	}

	/**
	 * Handle bulk booking cancellation.
	 */
	private function handle_bulk_cancel() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Unauthorized.', 'lets-meet' ) );
		}

		// WP_List_Table uses _wpnonce with action 'bulk-bookings'.
		if ( ! wp_verify_nonce( $_POST['_wpnonce'] ?? '', 'bulk-bookings' ) ) {
			wp_die( esc_html__( 'Invalid nonce. Please try again.', 'lets-meet' ) );
		}

		$ids = array_map( 'absint', (array) ( $_POST['booking_ids'] ?? [] ) );
		$cancelled = 0;

		foreach ( $ids as $id ) {
			if ( $id > 0 && $this->bookings->cancel( $id ) ) {
				$cancelled++;
			}
		}

		wp_safe_redirect( add_query_arg( [
			'page'      => 'lets-meet',
			'cancelled' => $cancelled,
		], admin_url( 'admin.php' ) ) );
		exit;
	}

	/* ── Payment override handlers ────────────────────────────────── */

	/**
	 * Handle admin marking a booking as paid.
	 */
	public function handle_mark_paid() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Unauthorized', 'lets-meet' ) );
		}

		$booking_id = absint( $_POST['booking_id'] ?? 0 );
		check_admin_referer( 'lm_mark_paid_' . $booking_id, 'lm_nonce' );

		global $wpdb;
		$table = $wpdb->prefix . 'lm_bookings';

		$booking = $this->bookings->get( $booking_id );
		if ( ! $booking || 'pending' !== ( $booking->payment_status ?? '' ) ) {
			wp_safe_redirect( admin_url( 'admin.php?page=lets-meet' ) );
			exit;
		}

		$amount = number_format( (float) ( $_POST['amount'] ?? 0 ), 2, '.', '' );
		$txn_id = sanitize_text_field( $_POST['txn_id'] ?? '' );

		$wpdb->update(
			$table,
			[
				'status'         => 'confirmed',
				'payment_status' => 'paid',
				'payment_amount' => $amount,
				'payment_txn_id' => $txn_id ?: 'manual',
				'payment_date'   => current_time( 'mysql', true ),
			],
			[ 'id' => $booking_id ],
			[ '%s', '%s', '%f', '%s', '%s' ],
			[ '%d' ]
		);

		// Push GCal event and fire emails (same as IPN confirmation).
		$services = new Lets_Meet_Services();
		$service  = $services->get( $booking->service_id );

		$gcal = new Lets_Meet_Gcal();
		$gcal_event_id = $gcal->push_event( [
			'booking_id'   => $booking_id,
			'start_utc'    => $booking->start_utc,
			'duration'     => $booking->duration,
			'client_name'  => $booking->client_name,
			'client_email' => $booking->client_email,
			'client_phone' => $booking->client_phone,
			'client_notes' => $booking->client_notes,
			'service_name' => $service ? $service->name : '',
		] );

		if ( $gcal_event_id ) {
			$wpdb->update( $table, [ 'gcal_event_id' => $gcal_event_id ], [ 'id' => $booking_id ], [ '%s' ], [ '%d' ] );
		}

		try {
			$tz = new \DateTimeZone( $booking->site_timezone ?: wp_timezone_string() );
		} catch ( \Exception $e ) {
			$tz = wp_timezone();
		}
		$start = new \DateTimeImmutable( $booking->start_utc, new \DateTimeZone( 'UTC' ) );
		$local = $start->setTimezone( $tz );

		$booking_data = [
			'booking_id'     => $booking_id,
			'service_id'     => $booking->service_id,
			'service_name'   => $service ? $service->name : '',
			'client_name'    => $booking->client_name,
			'client_email'   => $booking->client_email,
			'client_phone'   => $booking->client_phone,
			'client_notes'   => $booking->client_notes,
			'start_utc'      => $booking->start_utc,
			'duration'       => $booking->duration,
			'site_timezone'  => $booking->site_timezone,
			'cancel_token'   => $booking->cancel_token,
			'date_display'   => wp_date( 'l, F j, Y', $local->getTimestamp() ),
			'time_display'   => wp_date( 'g:i A', $local->getTimestamp() ),
			'payment_status' => 'paid',
			'payment_amount' => $amount,
			'payment_txn_id' => $txn_id ?: 'manual',
		];

		do_action( 'lm_booking_created', $booking_id, $booking_data );

		wp_safe_redirect( add_query_arg( [
			'page'            => 'lets-meet',
			'action'          => 'view',
			'booking_id'      => $booking_id,
			'payment_updated' => '1',
		], admin_url( 'admin.php' ) ) );
		exit;
	}

	/**
	 * Handle admin marking a booking as waived (no payment taken).
	 */
	public function handle_mark_waived() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Unauthorized', 'lets-meet' ) );
		}

		$booking_id = absint( $_POST['booking_id'] ?? 0 );
		check_admin_referer( 'lm_mark_waived_' . $booking_id, 'lm_nonce' );

		global $wpdb;
		$table = $wpdb->prefix . 'lm_bookings';

		$booking = $this->bookings->get( $booking_id );
		if ( ! $booking || 'pending' !== ( $booking->payment_status ?? '' ) ) {
			wp_safe_redirect( admin_url( 'admin.php?page=lets-meet' ) );
			exit;
		}

		$wpdb->update(
			$table,
			[
				'status'         => 'confirmed',
				'payment_status' => 'waived',
			],
			[ 'id' => $booking_id ],
			[ '%s', '%s' ],
			[ '%d' ]
		);

		// Push GCal event and fire emails.
		$services = new Lets_Meet_Services();
		$service  = $services->get( $booking->service_id );

		$gcal = new Lets_Meet_Gcal();
		$gcal_event_id = $gcal->push_event( [
			'booking_id'   => $booking_id,
			'start_utc'    => $booking->start_utc,
			'duration'     => $booking->duration,
			'client_name'  => $booking->client_name,
			'client_email' => $booking->client_email,
			'client_phone' => $booking->client_phone,
			'client_notes' => $booking->client_notes,
			'service_name' => $service ? $service->name : '',
		] );

		if ( $gcal_event_id ) {
			$wpdb->update( $table, [ 'gcal_event_id' => $gcal_event_id ], [ 'id' => $booking_id ], [ '%s' ], [ '%d' ] );
		}

		try {
			$tz = new \DateTimeZone( $booking->site_timezone ?: wp_timezone_string() );
		} catch ( \Exception $e ) {
			$tz = wp_timezone();
		}
		$start = new \DateTimeImmutable( $booking->start_utc, new \DateTimeZone( 'UTC' ) );
		$local = $start->setTimezone( $tz );

		$booking_data = [
			'booking_id'    => $booking_id,
			'service_id'    => $booking->service_id,
			'service_name'  => $service ? $service->name : '',
			'client_name'   => $booking->client_name,
			'client_email'  => $booking->client_email,
			'client_phone'  => $booking->client_phone,
			'client_notes'  => $booking->client_notes,
			'start_utc'     => $booking->start_utc,
			'duration'      => $booking->duration,
			'site_timezone' => $booking->site_timezone,
			'cancel_token'  => $booking->cancel_token,
			'date_display'  => wp_date( 'l, F j, Y', $local->getTimestamp() ),
			'time_display'  => wp_date( 'g:i A', $local->getTimestamp() ),
		];

		do_action( 'lm_booking_created', $booking_id, $booking_data );

		wp_safe_redirect( add_query_arg( [
			'page'            => 'lets-meet',
			'action'          => 'view',
			'booking_id'      => $booking_id,
			'payment_updated' => '1',
		], admin_url( 'admin.php' ) ) );
		exit;
	}

	/* ── Settings page ─────────────────────────────────────────────── */

	/**
	 * Render the settings page with tabs.
	 */
	public function render_settings_page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		$tabs = [
			'availability' => __( 'Availability', 'lets-meet' ),
			'gcal'         => __( 'Google Calendar', 'lets-meet' ),
			'zoom'         => __( 'Zoom', 'lets-meet' ),
			'email'        => __( 'Email', 'lets-meet' ),
			'general'      => __( 'General', 'lets-meet' ),
		];

		$current_tab = sanitize_text_field( $_GET['tab'] ?? 'availability' );
		if ( ! array_key_exists( $current_tab, $tabs ) ) {
			$current_tab = 'availability';
		}

		// Admin notices.
		if ( isset( $_GET['updated'] ) ) {
			echo '<div class="notice notice-success is-dismissible"><p>' . esc_html__( 'Settings saved.', 'lets-meet' ) . '</p></div>';
		}

		$errors = get_transient( 'lm_admin_error_' . get_current_user_id() );
		if ( $errors ) {
			delete_transient( 'lm_admin_error_' . get_current_user_id() );
			echo '<div class="notice notice-error is-dismissible">';
			foreach ( (array) $errors as $err ) {
				echo '<p>' . esc_html( $err ) . '</p>';
			}
			echo '</div>';
		}
		?>
		<div class="wrap">
			<h1><?php esc_html_e( 'Let\'s Meet Settings', 'lets-meet' ); ?></h1>

			<nav class="nav-tab-wrapper">
				<?php foreach ( $tabs as $slug => $label ) : ?>
					<a href="<?php echo esc_url( admin_url( 'admin.php?page=lets-meet-settings&tab=' . $slug ) ); ?>"
						class="nav-tab <?php echo $current_tab === $slug ? 'nav-tab-active' : ''; ?>">
						<?php echo esc_html( $label ); ?>
					</a>
				<?php endforeach; ?>
			</nav>

			<div class="lm-settings-content">
				<?php
				switch ( $current_tab ) {
					case 'availability':
						$this->render_tab_availability();
						break;
					case 'gcal':
						$this->render_tab_gcal();
						break;
					case 'zoom':
						$this->render_tab_zoom();
						break;
					case 'email':
						$this->render_tab_email();
						break;
					case 'general':
						$this->render_tab_general();
						break;
				}
				?>
			</div>
		</div>
		<?php
	}

	/**
	 * Handle saving Google Calendar credentials.
	 */
	public function handle_save_gcal_settings() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Unauthorized', 'lets-meet' ) );
		}

		check_admin_referer( 'lm_save_gcal_settings', 'lm_nonce' );

		$client_id     = sanitize_text_field( $_POST['lm_gcal_client_id'] ?? '' );
		$client_secret = sanitize_text_field( $_POST['lm_gcal_client_secret'] ?? '' );
		$calendar_id   = sanitize_text_field( $_POST['lm_gcal_calendar_id'] ?? 'primary' );

		// If secret is empty and we already have one saved, keep it.
		if ( '' === $client_secret && $this->gcal->is_connected() ) {
			// Only update client_id and calendar_id.
			if ( false === get_option( 'lm_gcal_client_id' ) ) {
				add_option( 'lm_gcal_client_id', $client_id, '', 'no' );
			} else {
				update_option( 'lm_gcal_client_id', $client_id, 'no' );
			}
			if ( '' === $calendar_id ) {
				$calendar_id = 'primary';
			}
			if ( false === get_option( 'lm_gcal_calendar_id' ) ) {
				add_option( 'lm_gcal_calendar_id', $calendar_id, '', 'no' );
			} else {
				update_option( 'lm_gcal_calendar_id', $calendar_id, 'no' );
			}
		} else {
			$this->gcal->save_credentials( $client_id, $client_secret, $calendar_id );
		}

		wp_safe_redirect( admin_url( 'admin.php?page=lets-meet-settings&tab=gcal&updated=1' ) );
		exit;
	}

	/**
	 * Handle disconnecting Google Calendar.
	 */
	public function handle_gcal_disconnect() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Unauthorized', 'lets-meet' ) );
		}

		check_admin_referer( 'lm_gcal_disconnect' );

		$this->gcal->disconnect();

		wp_safe_redirect( admin_url( 'admin.php?page=lets-meet-settings&tab=gcal&gcal_disconnected=1' ) );
		exit;
	}

	/**
	 * Handle saving Zoom credentials.
	 */
	public function handle_save_zoom_settings() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Unauthorized', 'lets-meet' ) );
		}

		check_admin_referer( 'lm_save_zoom_settings', 'lm_nonce' );

		$account_id    = sanitize_text_field( $_POST['lm_zoom_account_id'] ?? '' );
		$client_id     = sanitize_text_field( $_POST['lm_zoom_client_id'] ?? '' );
		$client_secret = sanitize_text_field( $_POST['lm_zoom_client_secret'] ?? '' );

		// If secret is empty and we already have one saved, keep it (only update account_id and client_id).
		if ( '' === $client_secret && $this->zoom && $this->zoom->is_connected() ) {
			if ( false === get_option( 'lm_zoom_account_id' ) ) {
				add_option( 'lm_zoom_account_id', $account_id, '', 'no' );
			} else {
				update_option( 'lm_zoom_account_id', $account_id, 'no' );
			}
			if ( false === get_option( 'lm_zoom_client_id' ) ) {
				add_option( 'lm_zoom_client_id', $client_id, '', 'no' );
			} else {
				update_option( 'lm_zoom_client_id', $client_id, 'no' );
			}
		} elseif ( $this->zoom ) {
			$this->zoom->save_credentials( $account_id, $client_id, $client_secret );
		}

		wp_safe_redirect( admin_url( 'admin.php?page=lets-meet-settings&tab=zoom&updated=1' ) );
		exit;
	}

	/**
	 * Handle disconnecting Zoom.
	 */
	public function handle_zoom_disconnect() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Unauthorized', 'lets-meet' ) );
		}

		check_admin_referer( 'lm_zoom_disconnect' );

		if ( $this->zoom ) {
			$this->zoom->disconnect();
		}

		wp_safe_redirect( admin_url( 'admin.php?page=lets-meet-settings&tab=zoom&zoom_disconnected=1' ) );
		exit;
	}

	/**
	 * Handle saving settings from any tab.
	 */
	public function handle_save_settings() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Unauthorized', 'lets-meet' ) );
		}

		check_admin_referer( 'lm_save_settings', 'lm_nonce' );

		$tab        = sanitize_text_field( $_POST['lm_tab'] ?? 'availability' );
		$valid_tabs = [ 'availability', 'email', 'general' ];

		if ( ! in_array( $tab, $valid_tabs, true ) ) {
			wp_die( esc_html__( 'Invalid tab.', 'lets-meet' ) );
		}

		$has_errors = false;

		switch ( $tab ) {
			case 'availability':
				$has_errors = $this->save_tab_availability();
				break;
			case 'email':
				$this->save_tab_email();
				break;
			case 'general':
				$this->save_tab_general();
				break;
		}

		$redirect = admin_url( 'admin.php?page=lets-meet-settings&tab=' . $tab );
		if ( ! $has_errors ) {
			$redirect = add_query_arg( 'updated', '1', $redirect );
		}
		wp_safe_redirect( $redirect );
		exit;
	}

	/* ── Settings tab renderers ────────────────────────────────────── */

	/**
	 * Render the Availability tab.
	 */
	private function render_tab_availability() {
		$availability = get_option( 'lm_availability', [] );
		$settings     = get_option( 'lm_settings', [] );
		$days         = [ 'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday', 'sunday' ];
		$day_labels   = [
			'monday'    => __( 'Monday', 'lets-meet' ),
			'tuesday'   => __( 'Tuesday', 'lets-meet' ),
			'wednesday' => __( 'Wednesday', 'lets-meet' ),
			'thursday'  => __( 'Thursday', 'lets-meet' ),
			'friday'    => __( 'Friday', 'lets-meet' ),
			'saturday'  => __( 'Saturday', 'lets-meet' ),
			'sunday'    => __( 'Sunday', 'lets-meet' ),
		];
		$time_options = $this->get_time_options();
		?>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
			<input type="hidden" name="action" value="lm_save_settings">
			<input type="hidden" name="lm_tab" value="availability">
			<?php wp_nonce_field( 'lm_save_settings', 'lm_nonce' ); ?>

			<h2><?php esc_html_e( 'Weekly Schedule', 'lets-meet' ); ?></h2>
			<p class="description">
				<?php esc_html_e( 'Set up to 3 availability windows per day. Leave a row blank to skip it.', 'lets-meet' ); ?>
			</p>

			<div class="lm-availability-grid">
				<?php foreach ( $days as $index => $day ) :
					$windows = $availability[ $day ] ?? [];
				?>
					<div class="lm-day" data-day="<?php echo esc_attr( $day ); ?>">
						<h3>
							<?php echo esc_html( $day_labels[ $day ] ); ?>
							<?php if ( $index < 6 ) : ?>
								<button type="button" class="button button-small lm-copy-right"
									data-from="<?php echo esc_attr( $day ); ?>"
									data-to="<?php echo esc_attr( $days[ $index + 1 ] ); ?>"
									title="<?php esc_attr_e( 'Copy to next day', 'lets-meet' ); ?>">
									<?php echo esc_html__( 'Copy', 'lets-meet' ) . ' &rarr;'; ?>
								</button>
							<?php endif; ?>
						</h3>
						<?php for ( $slot = 0; $slot < 3; $slot++ ) :
							$start = $windows[ $slot ]['start'] ?? '';
							$end   = $windows[ $slot ]['end'] ?? '';
						?>
							<div class="lm-slot-row">
								<select name="lm_avail[<?php echo esc_attr( $day ); ?>][<?php echo absint( $slot ); ?>][start]">
									<option value="">&mdash;</option>
									<?php foreach ( $time_options as $val => $label ) : ?>
										<option value="<?php echo esc_attr( $val ); ?>"
											<?php selected( $val, $start ); ?>>
											<?php echo esc_html( $label ); ?>
										</option>
									<?php endforeach; ?>
								</select>
								<span class="lm-to"><?php esc_html_e( 'to', 'lets-meet' ); ?></span>
								<select name="lm_avail[<?php echo esc_attr( $day ); ?>][<?php echo absint( $slot ); ?>][end]">
									<option value="">&mdash;</option>
									<?php foreach ( $time_options as $val => $label ) : ?>
										<option value="<?php echo esc_attr( $val ); ?>"
											<?php selected( $val, $end ); ?>>
											<?php echo esc_html( $label ); ?>
										</option>
									<?php endforeach; ?>
								</select>
							</div>
						<?php endfor; ?>
					</div>
				<?php endforeach; ?>
			</div>

			<h2><?php esc_html_e( 'Booking Rules', 'lets-meet' ); ?></h2>
			<table class="form-table">
				<tr>
					<th scope="row">
						<label for="lm-buffer"><?php esc_html_e( 'Buffer Time', 'lets-meet' ); ?></label>
					</th>
					<td>
						<select id="lm-buffer" name="lm_buffer">
							<?php foreach ( [ 15, 30, 45, 60 ] as $mins ) : ?>
								<option value="<?php echo absint( $mins ); ?>"
									<?php selected( $mins, absint( $settings['buffer'] ?? 30 ) ); ?>>
									<?php
									printf(
										/* translators: %d: number of minutes */
										esc_html__( '%d minutes', 'lets-meet' ),
										$mins
									);
									?>
								</option>
							<?php endforeach; ?>
						</select>
						<p class="description">
							<?php esc_html_e( 'Buffer before and after every booking and calendar event.', 'lets-meet' ); ?>
						</p>
					</td>
				</tr>
				<tr>
					<th scope="row">
						<label for="lm-notice"><?php esc_html_e( 'Minimum Notice', 'lets-meet' ); ?></label>
					</th>
					<td>
						<select id="lm-notice" name="lm_min_notice">
							<?php foreach ( [ 1, 2, 4, 8, 24 ] as $hours ) : ?>
								<option value="<?php echo absint( $hours ); ?>"
									<?php selected( $hours, absint( $settings['min_notice'] ?? 2 ) ); ?>>
									<?php
									printf(
										/* translators: %d: number of hours */
										esc_html( _n( '%d hour', '%d hours', $hours, 'lets-meet' ) ),
										$hours
									);
									?>
								</option>
							<?php endforeach; ?>
						</select>
						<p class="description">
							<?php esc_html_e( 'How far in advance a visitor must book.', 'lets-meet' ); ?>
						</p>
					</td>
				</tr>
				<tr>
					<th scope="row">
						<label for="lm-horizon"><?php esc_html_e( 'Booking Horizon', 'lets-meet' ); ?></label>
					</th>
					<td>
						<select id="lm-horizon" name="lm_horizon">
							<?php foreach ( [ 14, 30, 60, 90 ] as $d ) : ?>
								<option value="<?php echo absint( $d ); ?>"
									<?php selected( $d, absint( $settings['horizon'] ?? 60 ) ); ?>>
									<?php
									printf(
										/* translators: %d: number of days */
										esc_html__( '%d days', 'lets-meet' ),
										$d
									);
									?>
								</option>
							<?php endforeach; ?>
						</select>
						<p class="description">
							<?php esc_html_e( 'How far into the future visitors can book.', 'lets-meet' ); ?>
						</p>
					</td>
				</tr>
			</table>

			<?php submit_button(); ?>
		</form>
		<?php
	}

	/**
	 * Render the Google Calendar tab (placeholder for Phase 5).
	 */
	private function render_tab_gcal() {
		$is_connected = $this->gcal->is_connected();
		$client_id    = get_option( 'lm_gcal_client_id', '' );
		$calendar_id  = get_option( 'lm_gcal_calendar_id', 'primary' );

		// Notices.
		if ( isset( $_GET['gcal_connected'] ) ) {
			echo '<div class="notice notice-success is-dismissible"><p>' . esc_html__( 'Google Calendar connected successfully.', 'lets-meet' ) . '</p></div>';
		}
		if ( isset( $_GET['gcal_disconnected'] ) ) {
			echo '<div class="notice notice-success is-dismissible"><p>' . esc_html__( 'Google Calendar disconnected.', 'lets-meet' ) . '</p></div>';
		}
		if ( isset( $_GET['gcal_error'] ) ) {
			$err = sanitize_text_field( $_GET['gcal_error'] );
			if ( 'auth_denied' === $err ) {
				echo '<div class="notice notice-error is-dismissible"><p>' . esc_html__( 'Google Calendar authorization was denied. Please try again.', 'lets-meet' ) . '</p></div>';
			} elseif ( 'token_exchange' === $err ) {
				echo '<div class="notice notice-error is-dismissible"><p>' . esc_html__( 'Failed to exchange authorization code. Please check your credentials and try again.', 'lets-meet' ) . '</p></div>';
			}
		}
		?>
		<h2><?php esc_html_e( 'Google Calendar', 'lets-meet' ); ?></h2>

		<?php if ( $is_connected ) : ?>
			<div class="lm-gcal-status lm-gcal-status--connected">
				<span class="dashicons dashicons-yes-alt"></span>
				<?php esc_html_e( 'Connected', 'lets-meet' ); ?>
			</div>
		<?php else : ?>
			<div class="lm-gcal-status lm-gcal-status--disconnected">
				<span class="dashicons dashicons-warning"></span>
				<?php esc_html_e( 'Not connected', 'lets-meet' ); ?>
			</div>
		<?php endif; ?>

		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
			<input type="hidden" name="action" value="lm_save_gcal_settings">
			<?php wp_nonce_field( 'lm_save_gcal_settings', 'lm_nonce' ); ?>

			<table class="form-table">
				<tr>
					<th scope="row">
						<label for="lm-gcal-client-id"><?php esc_html_e( 'Client ID', 'lets-meet' ); ?></label>
					</th>
					<td>
						<input type="text" id="lm-gcal-client-id" name="lm_gcal_client_id"
							value="<?php echo esc_attr( $client_id ); ?>"
							class="large-text">
					</td>
				</tr>
				<tr>
					<th scope="row">
						<label for="lm-gcal-client-secret"><?php esc_html_e( 'Client Secret', 'lets-meet' ); ?></label>
					</th>
					<td>
						<input type="password" id="lm-gcal-client-secret" name="lm_gcal_client_secret"
							value="" class="regular-text" autocomplete="new-password">
						<p class="description">
							<?php
							if ( $is_connected ) {
								esc_html_e( 'Leave blank to keep the current secret.', 'lets-meet' );
							} else {
								esc_html_e( 'Enter your Google OAuth Client Secret.', 'lets-meet' );
							}
							?>
						</p>
					</td>
				</tr>
				<tr>
					<th scope="row">
						<label for="lm-gcal-calendar-id"><?php esc_html_e( 'Calendar ID', 'lets-meet' ); ?></label>
					</th>
					<td>
						<input type="text" id="lm-gcal-calendar-id" name="lm_gcal_calendar_id"
							value="<?php echo esc_attr( $calendar_id ); ?>"
							class="regular-text">
						<p class="description">
							<?php esc_html_e( 'Default: primary. Use comma-separated email addresses to check multiple calendars (e.g. me@gmail.com,other@gmail.com).', 'lets-meet' ); ?>
						</p>
					</td>
				</tr>
			</table>

			<?php submit_button( __( 'Save Credentials', 'lets-meet' ) ); ?>
		</form>

		<hr>

		<?php if ( $is_connected ) : ?>
			<h3><?php esc_html_e( 'Connection', 'lets-meet' ); ?></h3>
			<p><?php esc_html_e( 'Your Google Calendar is connected. Availability will include your Google Calendar events.', 'lets-meet' ); ?></p>
			<a href="<?php echo esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=lm_gcal_disconnect' ), 'lm_gcal_disconnect' ) ); ?>"
				class="button" onclick="return confirm('<?php echo esc_js( __( 'Disconnect Google Calendar?', 'lets-meet' ) ); ?>');">
				<?php esc_html_e( 'Disconnect', 'lets-meet' ); ?>
			</a>
		<?php elseif ( '' !== $client_id ) : ?>
			<h3><?php esc_html_e( 'Connection', 'lets-meet' ); ?></h3>
			<p><?php esc_html_e( 'Credentials saved. Click below to authorize access to your Google Calendar.', 'lets-meet' ); ?></p>
			<a href="<?php echo esc_url( $this->gcal->get_auth_url() ); ?>" class="button button-primary">
				<?php esc_html_e( 'Connect Google Calendar', 'lets-meet' ); ?>
			</a>
		<?php else : ?>
			<p class="description">
				<?php esc_html_e( 'Enter your Google OAuth credentials above and save, then you can connect.', 'lets-meet' ); ?>
			</p>
		<?php endif;
	}

	/**
	 * Render the Zoom tab.
	 */
	private function render_tab_zoom() {
		$is_connected = $this->zoom && $this->zoom->is_connected();
		$account_id   = get_option( 'lm_zoom_account_id', '' );
		$client_id    = get_option( 'lm_zoom_client_id', '' );

		// Notices.
		if ( isset( $_GET['zoom_disconnected'] ) ) {
			echo '<div class="notice notice-success is-dismissible"><p>' . esc_html__( 'Zoom disconnected.', 'lets-meet' ) . '</p></div>';
		}
		if ( isset( $_GET['zoom_test'] ) && $this->zoom ) {
			check_admin_referer( 'lm_zoom_test' );
			$test_result = $this->zoom->test_connection();
			$notice_class = strpos( $test_result, 'Success' ) !== false ? 'notice-success' : 'notice-error';
			echo '<div class="notice ' . esc_attr( $notice_class ) . ' is-dismissible"><p><strong>' . esc_html__( 'Zoom Test:', 'lets-meet' ) . '</strong> ' . esc_html( $test_result ) . '</p></div>';
		}
		?>
		<h2><?php esc_html_e( 'Zoom Meetings', 'lets-meet' ); ?></h2>
		<p class="description">
			<?php esc_html_e( 'Auto-create Zoom meetings for virtual sessions. Follow the setup steps below, then enter your credentials.', 'lets-meet' ); ?>
		</p>

		<details style="margin: 16px 0 24px; padding: 16px 20px; background: #f0f6fc; border-radius: 6px; max-width: 700px;">
			<summary style="cursor: pointer; font-weight: 600; font-size: 14px; color: #1e1e1e;">
				<?php esc_html_e( 'Zoom Setup Instructions', 'lets-meet' ); ?>
			</summary>
			<ol style="margin: 12px 0 0; padding-left: 20px; font-size: 13px; color: #333; line-height: 1.8;">
				<li><?php echo wp_kses_post( __( 'Go to <a href="https://marketplace.zoom.us/" target="_blank">marketplace.zoom.us</a> and sign in with your Zoom account.', 'lets-meet' ) ); ?></li>
				<li><?php esc_html_e( 'Click Develop > Build App.', 'lets-meet' ); ?></li>
				<li><?php echo wp_kses_post( __( 'Choose <strong>Server-to-Server OAuth</strong> as the app type. (Do not choose "OAuth" — that is a different type.)', 'lets-meet' ) ); ?></li>
				<li><?php esc_html_e( 'Give your app a name (e.g. "My Booking Plugin") and create it.', 'lets-meet' ); ?></li>
				<li><?php echo wp_kses_post( __( 'On the <strong>App Credentials</strong> tab, copy the <strong>Account ID</strong>, <strong>Client ID</strong>, and <strong>Client Secret</strong>.', 'lets-meet' ) ); ?></li>
				<li><?php echo wp_kses_post( __( 'Go to the <strong>Scopes</strong> tab and add these scopes:', 'lets-meet' ) ); ?>
					<ul style="margin: 4px 0; padding-left: 16px; list-style: disc;">
						<li><code>meeting:write:meeting:admin</code> — <?php esc_html_e( 'Create a meeting', 'lets-meet' ); ?></li>
						<li><code>meeting:update:meeting:admin</code> — <?php esc_html_e( 'Update a meeting (for reschedule)', 'lets-meet' ); ?></li>
						<li><code>meeting:delete:meeting:admin</code> — <?php esc_html_e( 'Delete a meeting (for cancellation)', 'lets-meet' ); ?></li>
					</ul>
				</li>
				<li><?php echo wp_kses_post( __( 'Click <strong>Activate</strong> to activate the app.', 'lets-meet' ) ); ?></li>
				<li><?php esc_html_e( 'Paste your Account ID, Client ID, and Client Secret below and save.', 'lets-meet' ); ?></li>
				<li><?php esc_html_e( 'Use the "Test Connection" button to verify everything works.', 'lets-meet' ); ?></li>
				<li><?php esc_html_e( 'Finally, enable Zoom on each service under Services > Edit.', 'lets-meet' ); ?></li>
			</ol>
		</details>

		<?php if ( $is_connected ) : ?>
			<div class="lm-gcal-status lm-gcal-status--connected">
				<span class="dashicons dashicons-yes-alt"></span>
				<?php esc_html_e( 'Connected', 'lets-meet' ); ?>
			</div>
		<?php else : ?>
			<div class="lm-gcal-status lm-gcal-status--disconnected">
				<span class="dashicons dashicons-warning"></span>
				<?php esc_html_e( 'Not connected', 'lets-meet' ); ?>
			</div>
		<?php endif; ?>

		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
			<input type="hidden" name="action" value="lm_save_zoom_settings">
			<?php wp_nonce_field( 'lm_save_zoom_settings', 'lm_nonce' ); ?>

			<table class="form-table">
				<tr>
					<th scope="row">
						<label for="lm-zoom-account-id"><?php esc_html_e( 'Account ID', 'lets-meet' ); ?></label>
					</th>
					<td>
						<input type="text" id="lm-zoom-account-id" name="lm_zoom_account_id"
							value="<?php echo esc_attr( $account_id ); ?>"
							class="regular-text">
					</td>
				</tr>
				<tr>
					<th scope="row">
						<label for="lm-zoom-client-id"><?php esc_html_e( 'Client ID', 'lets-meet' ); ?></label>
					</th>
					<td>
						<input type="text" id="lm-zoom-client-id" name="lm_zoom_client_id"
							value="<?php echo esc_attr( $client_id ); ?>"
							class="regular-text">
					</td>
				</tr>
				<tr>
					<th scope="row">
						<label for="lm-zoom-client-secret"><?php esc_html_e( 'Client Secret', 'lets-meet' ); ?></label>
					</th>
					<td>
						<input type="password" id="lm-zoom-client-secret" name="lm_zoom_client_secret"
							value="" class="regular-text" autocomplete="new-password">
						<p class="description">
							<?php
							if ( $is_connected ) {
								esc_html_e( 'Leave blank to keep the current secret.', 'lets-meet' );
							} else {
								esc_html_e( 'Enter your Zoom Server-to-Server OAuth Client Secret.', 'lets-meet' );
							}
							?>
						</p>
					</td>
				</tr>
			</table>

			<?php submit_button( __( 'Save Credentials', 'lets-meet' ) ); ?>
		</form>

		<?php if ( $is_connected ) : ?>
			<hr>
			<p><?php esc_html_e( 'Zoom is connected. Enable Zoom per-service in the service editor.', 'lets-meet' ); ?></p>
			<p>
				<a href="<?php echo esc_url( wp_nonce_url( admin_url( 'admin.php?page=lets-meet-settings&tab=zoom&zoom_test=1' ), 'lm_zoom_test' ) ); ?>"
					class="button button-primary">
					<?php esc_html_e( 'Test Connection', 'lets-meet' ); ?>
				</a>
				&nbsp;
				<a href="<?php echo esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=lm_zoom_disconnect' ), 'lm_zoom_disconnect' ) ); ?>"
					class="button" onclick="return confirm('<?php echo esc_js( __( 'Disconnect Zoom?', 'lets-meet' ) ); ?>');">
					<?php esc_html_e( 'Disconnect', 'lets-meet' ); ?>
				</a>
			</p>
		<?php endif;
	}

	/**
	 * Render the Email tab.
	 */
	private function render_tab_email() {
		$settings = get_option( 'lm_settings', [] );
		?>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
			<input type="hidden" name="action" value="lm_save_settings">
			<input type="hidden" name="lm_tab" value="email">
			<?php wp_nonce_field( 'lm_save_settings', 'lm_nonce' ); ?>

			<table class="form-table">
				<tr>
					<th scope="row">
						<label for="lm-reply-to"><?php esc_html_e( 'Reply-To Email', 'lets-meet' ); ?></label>
					</th>
					<td>
						<input type="email" id="lm-reply-to" name="lm_admin_email"
							value="<?php echo esc_attr( $settings['admin_email'] ?? get_option( 'admin_email' ) ); ?>"
							class="regular-text">
						<p class="description">
							<?php esc_html_e( 'Reply-to address on client confirmation emails.', 'lets-meet' ); ?>
						</p>
					</td>
				</tr>
				<tr>
					<th scope="row">
						<label for="lm-confirm-msg"><?php esc_html_e( 'Confirmation Message', 'lets-meet' ); ?></label>
					</th>
					<td>
						<textarea id="lm-confirm-msg" name="lm_confirm_msg" rows="4"
							class="large-text"><?php echo esc_textarea( $settings['confirm_msg'] ?? '' ); ?></textarea>
						<p class="description">
							<?php esc_html_e( 'Custom message included in the client confirmation email.', 'lets-meet' ); ?>
						</p>
					</td>
				</tr>
				<tr>
					<th scope="row"><?php esc_html_e( 'Admin Notifications', 'lets-meet' ); ?></th>
					<td>
						<label for="lm-admin-notify">
							<input type="checkbox" id="lm-admin-notify" name="lm_admin_notify" value="1"
								<?php checked( ! empty( $settings['admin_notify'] ) ); ?>>
							<?php esc_html_e( 'Send me an email when a new booking is made.', 'lets-meet' ); ?>
						</label>
					</td>
				</tr>
			</table>

			<?php submit_button(); ?>
		</form>
		<?php
	}

	/**
	 * Render the General tab.
	 */
	private function render_tab_general() {
		$settings = get_option( 'lm_settings', [] );
		?>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
			<input type="hidden" name="action" value="lm_save_settings">
			<input type="hidden" name="lm_tab" value="general">
			<?php wp_nonce_field( 'lm_save_settings', 'lm_nonce' ); ?>

			<h3><?php esc_html_e( 'PayPal Payment', 'lets-meet' ); ?></h3>
			<table class="form-table">
				<tr>
					<th scope="row">
						<label for="lm-paypal-email"><?php esc_html_e( 'PayPal Email', 'lets-meet' ); ?></label>
					</th>
					<td>
						<input type="email" id="lm-paypal-email" name="lm_paypal_email"
							value="<?php echo esc_attr( $settings['paypal_email'] ?? '' ); ?>"
							class="regular-text">
						<p class="description">
							<?php esc_html_e( 'Your PayPal business email. Required for paid services.', 'lets-meet' ); ?>
						</p>
					</td>
				</tr>
				<tr>
					<th scope="row"><?php esc_html_e( 'Sandbox Mode', 'lets-meet' ); ?></th>
					<td>
						<label for="lm-paypal-sandbox">
							<input type="checkbox" id="lm-paypal-sandbox" name="lm_paypal_sandbox" value="1"
								<?php checked( ! empty( $settings['paypal_sandbox'] ) ); ?>>
							<?php esc_html_e( 'Enable PayPal Sandbox for testing (use sandbox.paypal.com).', 'lets-meet' ); ?>
						</label>
					</td>
				</tr>
			</table>

			<h3><?php esc_html_e( 'Other', 'lets-meet' ); ?></h3>
			<table class="form-table">
				<tr>
					<th scope="row"><?php esc_html_e( 'Uninstall Behavior', 'lets-meet' ); ?></th>
					<td>
						<label for="lm-keep-data">
							<input type="checkbox" id="lm-keep-data" name="lm_keep_data" value="1"
								<?php checked( ! empty( $settings['keep_data'] ) ); ?>>
							<?php esc_html_e( 'Keep all data (services, bookings, settings) when the plugin is uninstalled.', 'lets-meet' ); ?>
						</label>
						<p class="description">
							<?php esc_html_e( 'Uncheck this to remove all plugin data on uninstall. Default: keep data.', 'lets-meet' ); ?>
						</p>
					</td>
				</tr>
			</table>

			<?php submit_button(); ?>
		</form>
		<?php
	}

	/* ── Settings save handlers ────────────────────────────────────── */

	/**
	 * Save the Availability tab.
	 *
	 * @return bool True if validation errors occurred, false on success.
	 */
	private function save_tab_availability() {
		$days      = [ 'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday', 'sunday' ];
		$raw_avail = $_POST['lm_avail'] ?? [];
		$allowed   = $this->get_time_options();
		$schedule  = [];
		$errors    = [];

		foreach ( $days as $day ) {
			$schedule[ $day ] = [];
			$day_slots        = $raw_avail[ $day ] ?? [];

			for ( $i = 0; $i < 3; $i++ ) {
				$start = sanitize_text_field( $day_slots[ $i ]['start'] ?? '' );
				$end   = sanitize_text_field( $day_slots[ $i ]['end'] ?? '' );

				// Skip empty rows.
				if ( '' === $start && '' === $end ) {
					continue;
				}

				// Both must be set.
				if ( '' === $start || '' === $end ) {
					$errors[] = sprintf(
						/* translators: %s: day of week */
						__( '%s: Both start and end times are required for each window.', 'lets-meet' ),
						ucfirst( $day )
					);
					continue;
				}

				// Must be valid time values.
				if ( ! isset( $allowed[ $start ] ) || ! isset( $allowed[ $end ] ) ) {
					$errors[] = sprintf(
						/* translators: %s: day of week */
						__( '%s: Invalid time value.', 'lets-meet' ),
						ucfirst( $day )
					);
					continue;
				}

				// End must be after start.
				if ( $end <= $start ) {
					$errors[] = sprintf(
						/* translators: %s: day of week */
						__( '%s: End time must be after start time.', 'lets-meet' ),
						ucfirst( $day )
					);
					continue;
				}

				$schedule[ $day ][] = [ 'start' => $start, 'end' => $end ];
			}

			// Check for overlapping windows within the day.
			$windows = $schedule[ $day ];
			for ( $a = 0; $a < count( $windows ); $a++ ) {
				for ( $b = $a + 1; $b < count( $windows ); $b++ ) {
					if ( $windows[ $a ]['start'] < $windows[ $b ]['end'] && $windows[ $b ]['start'] < $windows[ $a ]['end'] ) {
						$errors[] = sprintf(
							/* translators: %s: day of week */
							__( '%s: Availability windows overlap.', 'lets-meet' ),
							ucfirst( $day )
						);
						break 2; // One overlap message per day is enough.
					}
				}
			}
		}

		if ( ! empty( $errors ) ) {
			set_transient( 'lm_admin_error_' . get_current_user_id(), $errors, 30 );
			// Do not save availability or booking rules when there are errors.
			return true;
		}

		update_option( 'lm_availability', $schedule );

		// Save booking rules.
		$settings = get_option( 'lm_settings', [] );

		$buffer = absint( $_POST['lm_buffer'] ?? 30 );
		if ( ! in_array( $buffer, [ 15, 30, 45, 60 ], true ) ) {
			$buffer = 30;
		}

		$min_notice = absint( $_POST['lm_min_notice'] ?? 2 );
		if ( ! in_array( $min_notice, [ 1, 2, 4, 8, 24 ], true ) ) {
			$min_notice = 2;
		}

		$horizon = absint( $_POST['lm_horizon'] ?? 60 );
		if ( ! in_array( $horizon, [ 14, 30, 60, 90 ], true ) ) {
			$horizon = 60;
		}

		$settings['buffer']     = $buffer;
		$settings['min_notice'] = $min_notice;
		$settings['horizon']    = $horizon;

		update_option( 'lm_settings', $settings );

		return false;
	}

	/**
	 * Save the Email tab.
	 */
	private function save_tab_email() {
		$settings = get_option( 'lm_settings', [] );

		$admin_email = sanitize_email( $_POST['lm_admin_email'] ?? '' );
		if ( ! is_email( $admin_email ) ) {
			$admin_email = get_option( 'admin_email' );
		}

		$settings['admin_email']  = $admin_email;
		$settings['confirm_msg']  = wp_kses_post( $_POST['lm_confirm_msg'] ?? '' );
		$settings['admin_notify'] = ! empty( $_POST['lm_admin_notify'] );

		update_option( 'lm_settings', $settings );
	}

	/**
	 * Save the General tab.
	 */
	private function save_tab_general() {
		$settings = get_option( 'lm_settings', [] );

		$settings['keep_data']       = ! empty( $_POST['lm_keep_data'] );
		$settings['paypal_email']    = sanitize_email( $_POST['lm_paypal_email'] ?? '' );
		$settings['paypal_sandbox']  = ! empty( $_POST['lm_paypal_sandbox'] );

		update_option( 'lm_settings', $settings );
	}

	/* ── Settings helpers ──────────────────────────────────────────── */

	/**
	 * Generate time options in 30-min increments (00:00–23:30).
	 *
	 * @return array Keyed by 'HH:MM' value, display label as value.
	 */
	private function get_time_options() {
		$options = [];
		$format  = get_option( 'time_format', 'g:i A' );
		$tz      = wp_timezone();
		for ( $h = 0; $h < 24; $h++ ) {
			for ( $m = 0; $m < 60; $m += 30 ) {
				$val = sprintf( '%02d:%02d', $h, $m );
				$dt  = new DateTimeImmutable( "2026-01-01 {$val}", $tz );
				$options[ $val ] = wp_date( $format, $dt->getTimestamp() );
			}
		}
		return $options;
	}

	/* ── Services page ─────────────────────────────────────────────── */

	/**
	 * Handle service form submissions, then render the services page.
	 */
	public function render_services_page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		$action  = sanitize_text_field( $_GET['action'] ?? '' );
		$edit_id = absint( $_GET['edit'] ?? 0 );

		echo '<div class="wrap">';

		if ( 'edit' === $action && $edit_id ) {
			$this->render_edit_form( $edit_id );
		} elseif ( 'new' === $action ) {
			$this->render_new_form();
		} else {
			$this->render_services_list();
		}

		echo '</div>';
	}

	/**
	 * Handle saving a service (add or edit).
	 */
	public function handle_save_service() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Unauthorized', 'lets-meet' ) );
		}

		check_admin_referer( 'lm_save_service', 'lm_nonce' );

		$validated = $this->services->validate( $_POST );

		if ( is_wp_error( $validated ) ) {
			// Store error in transient and redirect back.
			set_transient( 'lm_admin_error_' . get_current_user_id(), $validated->get_error_message(), 30 );
			wp_safe_redirect( wp_get_referer() );
			exit;
		}

		$service_id = absint( $_POST['service_id'] ?? 0 );

		if ( $service_id ) {
			$this->services->update( $service_id, $validated );
			$redirect = admin_url( 'admin.php?page=lets-meet-services&updated=1' );
		} else {
			$result = $this->services->create( $validated );
			if ( false === $result ) {
				set_transient( 'lm_admin_error_' . get_current_user_id(), __( 'Failed to create service. Please try again.', 'lets-meet' ), 30 );
				wp_safe_redirect( wp_get_referer() );
				exit;
			}
			$redirect = admin_url( 'admin.php?page=lets-meet-services&added=1' );
		}

		wp_safe_redirect( $redirect );
		exit;
	}

	/**
	 * Handle toggling a service active/inactive.
	 */
	public function handle_toggle_service() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Unauthorized', 'lets-meet' ) );
		}

		$service_id = absint( $_GET['service_id'] ?? 0 );

		check_admin_referer( 'lm_toggle_service_' . $service_id );

		if ( $service_id ) {
			$this->services->toggle_active( $service_id );
		}

		wp_safe_redirect( admin_url( 'admin.php?page=lets-meet-services&toggled=1' ) );
		exit;
	}

	/* ── Render helpers ────────────────────────────────────────────── */

	/**
	 * Render the services list table.
	 */
	private function render_services_list() {
		$services = $this->services->get_all();

		// Admin notices.
		if ( isset( $_GET['added'] ) ) {
			echo '<div class="notice notice-success is-dismissible"><p>' . esc_html__( 'Service added.', 'lets-meet' ) . '</p></div>';
		}
		if ( isset( $_GET['updated'] ) ) {
			echo '<div class="notice notice-success is-dismissible"><p>' . esc_html__( 'Service updated.', 'lets-meet' ) . '</p></div>';
		}
		if ( isset( $_GET['toggled'] ) ) {
			echo '<div class="notice notice-success is-dismissible"><p>' . esc_html__( 'Service status changed.', 'lets-meet' ) . '</p></div>';
		}

		$error = get_transient( 'lm_admin_error_' . get_current_user_id() );
		if ( $error ) {
			delete_transient( 'lm_admin_error_' . get_current_user_id() );
			echo '<div class="notice notice-error is-dismissible"><p>' . esc_html( $error ) . '</p></div>';
		}

		$new_url = admin_url( 'admin.php?page=lets-meet-services&action=new' );
		?>
		<h1>
			<?php esc_html_e( 'Services', 'lets-meet' ); ?>
			<a href="<?php echo esc_url( $new_url ); ?>" class="page-title-action">
				<?php esc_html_e( 'Add New', 'lets-meet' ); ?>
			</a>
		</h1>

		<?php if ( empty( $services ) ) : ?>
			<p><?php esc_html_e( 'No services yet. Add your first service to get started.', 'lets-meet' ); ?></p>
		<?php else : ?>
			<table class="wp-list-table widefat fixed striped">
				<thead>
					<tr>
						<th scope="col"><?php esc_html_e( 'Name', 'lets-meet' ); ?></th>
						<th scope="col"><?php esc_html_e( 'Slug', 'lets-meet' ); ?></th>
						<th scope="col"><?php esc_html_e( 'Duration', 'lets-meet' ); ?></th>
						<th scope="col"><?php esc_html_e( 'Price', 'lets-meet' ); ?></th>
						<th scope="col"><?php esc_html_e( 'Status', 'lets-meet' ); ?></th>
						<th scope="col"><?php esc_html_e( 'Actions', 'lets-meet' ); ?></th>
					</tr>
				</thead>
				<tbody>
					<?php foreach ( $services as $service ) : ?>
						<tr class="<?php echo $service->is_active ? '' : 'lm-inactive'; ?>">
							<td>
								<strong><?php echo esc_html( $service->name ); ?></strong>
								<?php if ( $service->description ) : ?>
									<br><span class="description"><?php echo esc_html( $service->description ); ?></span>
								<?php endif; ?>
							</td>
							<td><code><?php echo esc_html( $service->slug ); ?></code></td>
							<td>
								<?php
								printf(
									/* translators: %d: number of minutes */
									esc_html__( '%d min', 'lets-meet' ),
									absint( $service->duration )
								);
								?>
							</td>
							<td>
								<?php
								$svc_price = (float) ( $service->price ?? 0 );
								echo $svc_price > 0 ? '$' . esc_html( number_format( $svc_price, 2 ) ) : esc_html__( 'Free', 'lets-meet' );
								?>
							</td>
							<td>
								<?php if ( $service->is_active ) : ?>
									<span class="lm-status lm-status--active"><?php esc_html_e( 'Active', 'lets-meet' ); ?></span>
								<?php else : ?>
									<span class="lm-status lm-status--inactive"><?php esc_html_e( 'Inactive', 'lets-meet' ); ?></span>
								<?php endif; ?>
							</td>
							<td>
								<?php
								$edit_url   = admin_url( 'admin.php?page=lets-meet-services&action=edit&edit=' . absint( $service->id ) );
								$toggle_url = wp_nonce_url(
									admin_url( 'admin.php?page=lets-meet-services&action=toggle&service_id=' . absint( $service->id ) ),
									'lm_toggle_service_' . absint( $service->id )
								);
								$toggle_label = $service->is_active
									? __( 'Deactivate', 'lets-meet' )
									: __( 'Activate', 'lets-meet' );
								?>
								<a href="<?php echo esc_url( $edit_url ); ?>"><?php esc_html_e( 'Edit', 'lets-meet' ); ?></a>
								&nbsp;|&nbsp;
								<a href="<?php echo esc_url( $toggle_url ); ?>"><?php echo esc_html( $toggle_label ); ?></a>
							</td>
						</tr>
					<?php endforeach; ?>
				</tbody>
			</table>
		<?php endif;
	}

	/**
	 * Render the "add new service" form.
	 */
	private function render_new_form() {
		?>
		<h1><?php esc_html_e( 'Add New Service', 'lets-meet' ); ?></h1>
		<?php $this->render_service_form( null ); ?>
		<?php
	}

	/**
	 * Render the "edit service" form.
	 */
	private function render_edit_form( $id ) {
		$service = $this->services->get( $id );
		if ( ! $service ) {
			echo '<div class="notice notice-error"><p>' . esc_html__( 'Service not found.', 'lets-meet' ) . '</p></div>';
			return;
		}
		?>
		<h1><?php esc_html_e( 'Edit Service', 'lets-meet' ); ?></h1>
		<?php $this->render_service_form( $service ); ?>
		<?php
	}

	/**
	 * Render the service form (shared between add/edit).
	 *
	 * @param object|null $service Existing service for editing, or null for new.
	 */
	private function render_service_form( $service ) {
		$error = get_transient( 'lm_admin_error_' . get_current_user_id() );
		if ( $error ) {
			delete_transient( 'lm_admin_error_' . get_current_user_id() );
			echo '<div class="notice notice-error"><p>' . esc_html( $error ) . '</p></div>';
		}

		$name         = $service->name ?? '';
		$duration     = $service->duration ?? 60;
		$description  = $service->description ?? '';
		$price        = $service->price ?? '0.00';
		$zoom_enabled = $service->zoom_enabled ?? 0;
		$service_id   = $service->id ?? 0;
		$back_url    = admin_url( 'admin.php?page=lets-meet-services' );
		?>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
			<input type="hidden" name="action" value="lm_save_service">
			<input type="hidden" name="service_id" value="<?php echo absint( $service_id ); ?>">
			<?php wp_nonce_field( 'lm_save_service', 'lm_nonce' ); ?>

			<table class="form-table">
				<tr>
					<th scope="row">
						<label for="lm-name"><?php esc_html_e( 'Name', 'lets-meet' ); ?></label>
					</th>
					<td>
						<input type="text" id="lm-name" name="name" value="<?php echo esc_attr( $name ); ?>"
							class="regular-text" required>
					</td>
				</tr>
				<tr>
					<th scope="row">
						<label for="lm-duration"><?php esc_html_e( 'Duration (minutes)', 'lets-meet' ); ?></label>
					</th>
					<td>
						<select id="lm-duration" name="duration">
							<?php for ( $m = 15; $m <= 240; $m += 5 ) : ?>
								<option value="<?php echo absint( $m ); ?>"
									<?php selected( $m, absint( $duration ) ); ?>>
									<?php
									if ( $m < 60 ) {
										printf(
											/* translators: %d: number of minutes */
											esc_html__( '%d min', 'lets-meet' ),
											$m
										);
									} elseif ( $m % 60 === 0 ) {
										printf(
											/* translators: %d: number of hours */
											esc_html( _n( '%d hour', '%d hours', $m / 60, 'lets-meet' ) ),
											$m / 60
										);
									} else {
										printf(
											/* translators: 1: hours, 2: minutes */
											esc_html__( '%1$dh %2$dm', 'lets-meet' ),
											floor( $m / 60 ),
											$m % 60
										);
									}
									?>
								</option>
							<?php endfor; ?>
						</select>
					</td>
				</tr>
				<tr>
					<th scope="row">
						<label for="lm-price"><?php esc_html_e( 'Price ($)', 'lets-meet' ); ?></label>
					</th>
					<td>
						<input type="number" id="lm-price" name="price" value="<?php echo esc_attr( $price ); ?>"
							class="small-text" min="0" step="0.01">
						<p class="description"><?php esc_html_e( 'Set to 0.00 for free services. Any positive amount requires PayPal payment.', 'lets-meet' ); ?></p>
					</td>
				</tr>
				<tr>
					<th scope="row">
						<label for="lm-description"><?php esc_html_e( 'Description', 'lets-meet' ); ?></label>
					</th>
					<td>
						<textarea id="lm-description" name="description" rows="4"
							class="large-text"><?php echo esc_textarea( $description ); ?></textarea>
						<p class="description"><?php esc_html_e( 'Optional. Shown to visitors on the booking page.', 'lets-meet' ); ?></p>
					</td>
				</tr>
				<tr>
					<th scope="row"><?php esc_html_e( 'Zoom Meeting', 'lets-meet' ); ?></th>
					<td>
						<label for="lm-zoom-enabled">
							<input type="checkbox" id="lm-zoom-enabled" name="zoom_enabled" value="1"
								<?php checked( $zoom_enabled ); ?>>
							<?php esc_html_e( 'Auto-create a Zoom meeting for this service', 'lets-meet' ); ?>
						</label>
						<?php if ( ! $this->zoom || ! $this->zoom->is_connected() ) : ?>
							<p class="description" style="color: #b32d2e;">
								<?php esc_html_e( 'Zoom is not connected. Connect Zoom in Settings > Zoom to use this feature.', 'lets-meet' ); ?>
							</p>
						<?php endif; ?>
					</td>
				</tr>
			</table>

			<?php submit_button( $service_id ? __( 'Update Service', 'lets-meet' ) : __( 'Add Service', 'lets-meet' ) ); ?>
			<a href="<?php echo esc_url( $back_url ); ?>"><?php esc_html_e( '&larr; Back to Services', 'lets-meet' ); ?></a>
		</form>
		<?php
	}
}
