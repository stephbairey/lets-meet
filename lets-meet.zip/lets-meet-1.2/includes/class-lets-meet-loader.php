<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Hook registration orchestrator.
 *
 * Instantiates plugin classes and wires their methods to WordPress hooks.
 * New hooks are added here as each phase is built.
 */
class Lets_Meet_Loader {

	/**
	 * Register all hooks for the plugin.
	 */
	public function run() {
		// Check for DB schema upgrades on every admin load.
		$db = new Lets_Meet_Db();
		add_action( 'admin_init', [ $db, 'maybe_upgrade' ] );

		// Core classes.
		$services     = new Lets_Meet_Services();
		$gcal         = new Lets_Meet_Gcal();
		$zoom         = new Lets_Meet_Zoom();
		$availability = new Lets_Meet_Availability( $services, $gcal );
		$bookings     = new Lets_Meet_Bookings( $services, $availability, $gcal, $zoom );

		// Admin: menu, assets, form handlers.
		$admin = new Lets_Meet_Admin( $services, $gcal, $bookings, $zoom );

		add_action( 'admin_init', [ $admin, 'handle_early_actions' ] );
		add_action( 'admin_menu', [ $admin, 'register_menu' ] );
		add_action( 'admin_enqueue_scripts', [ $admin, 'enqueue_admin_assets' ] );
		add_action( 'admin_post_lm_save_service', [ $admin, 'handle_save_service' ] );
		add_action( 'admin_post_lm_save_settings', [ $admin, 'handle_save_settings' ] );
		add_action( 'admin_post_lm_admin_reschedule', [ $admin, 'handle_admin_reschedule' ] );
		add_action( 'admin_post_lm_mark_paid', [ $admin, 'handle_mark_paid' ] );
		add_action( 'admin_post_lm_mark_waived', [ $admin, 'handle_mark_waived' ] );

		// Google Calendar: OAuth callback, credentials, admin notice, prewarm cron.
		add_action( 'admin_post_lm_gcal_callback', [ $gcal, 'handle_oauth_callback' ] );
		add_action( 'admin_post_lm_save_gcal_settings', [ $admin, 'handle_save_gcal_settings' ] );
		add_action( 'admin_post_lm_gcal_disconnect', [ $admin, 'handle_gcal_disconnect' ] );
		add_action( 'admin_notices', [ $gcal, 'maybe_show_admin_notice' ] );
		add_action( 'lm_prewarm_gcal', [ $gcal, 'prewarm_cache' ] );

		// Zoom: settings, disconnect, admin notice.
		add_action( 'admin_post_lm_save_zoom_settings', [ $admin, 'handle_save_zoom_settings' ] );
		add_action( 'admin_post_lm_zoom_disconnect', [ $admin, 'handle_zoom_disconnect' ] );
		add_action( 'admin_notices', [ $zoom, 'maybe_show_admin_notice' ] );

		// PayPal IPN endpoint.
		$paypal = new Lets_Meet_Paypal();
		add_action( 'init', [ $paypal, 'register_ipn_endpoint' ] );
		add_filter( 'query_vars', [ $paypal, 'register_query_vars' ] );
		add_action( 'template_redirect', [ $paypal, 'maybe_handle_ipn' ] );

		// Frontend: shortcode, assets, AJAX.
		$public = new Lets_Meet_Public( $services, $availability, $bookings );

		add_action( 'init', [ $public, 'register_shortcode' ] );
		add_action( 'wp_enqueue_scripts', [ $public, 'enqueue_public_assets' ] );
		add_action( 'template_redirect', [ $public, 'handle_client_action' ] );
		add_action( 'wp_ajax_lm_get_slots', [ $public, 'ajax_get_slots' ] );
		add_action( 'wp_ajax_nopriv_lm_get_slots', [ $public, 'ajax_get_slots' ] );
		add_action( 'wp_ajax_lm_submit_booking', [ $public, 'ajax_submit_booking' ] );
		add_action( 'wp_ajax_nopriv_lm_submit_booking', [ $public, 'ajax_submit_booking' ] );
		add_action( 'wp_ajax_lm_reschedule_booking', [ $public, 'ajax_reschedule_booking' ] );
		add_action( 'wp_ajax_nopriv_lm_reschedule_booking', [ $public, 'ajax_reschedule_booking' ] );
		add_action( 'admin_post_lm_client_cancel', [ $public, 'handle_client_cancel' ] );
		add_action( 'admin_post_nopriv_lm_client_cancel', [ $public, 'handle_client_cancel' ] );

		// Email confirmations.
		$email = new Lets_Meet_Email();
		add_action( 'lm_booking_created', [ $email, 'send_confirmation' ], 10, 2 );
		add_action( 'lm_booking_cancelled', [ $email, 'send_cancellation_email' ], 10, 1 );
		add_action( 'lm_booking_rescheduled', [ $email, 'send_reschedule_confirmation' ], 10, 2 );

		// Privacy: GDPR personal data exporter + eraser.
		$privacy = new Lets_Meet_Privacy();
		add_filter( 'wp_privacy_personal_data_exporters', [ $privacy, 'register_exporter' ] );
		add_filter( 'wp_privacy_personal_data_erasers', [ $privacy, 'register_eraser' ] );
	}
}
